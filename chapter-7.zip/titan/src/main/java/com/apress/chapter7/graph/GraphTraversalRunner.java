package com.apress.chapter7.graph;

import java.util.Iterator;
import java.util.Map;

import org.apache.commons.configuration.BaseConfiguration;
import org.apache.commons.configuration.Configuration;

import com.thinkaurelius.titan.core.TitanFactory;
import com.thinkaurelius.titan.core.TitanGraph;
import com.thinkaurelius.titan.core.TitanMultiVertexQuery;
import com.thinkaurelius.titan.core.TitanVertex;
import com.tinkerpop.blueprints.Direction;
import com.tinkerpop.blueprints.Vertex;

/**
 * 
 * @author vivek.mishra
 * 
 * Source code for Ram-Dashrath family graph example.
 * Please refer chapter 7 "Faster Deep Traversal" section for more instructions.
 *
 */
public class GraphTraversalRunner {

	public static void main(String[] args) {
		Configuration conf = new BaseConfiguration();
		conf.setProperty("storage.backend", "cassandrathrift");
		conf.setProperty("storage.hostname", "localhost");
		conf.setProperty("storage.port", "9160");
		conf.setProperty("storage.keyspace", "multivertex");

		TitanGraph graph = TitanFactory.open(conf);

		// add followers for account
		// tweets of each followers using multi vertext query.

		// add people
		// add
		onDataFeed(graph);

	}

	private static void onDataFeed(TitanGraph graph) {
		/**
		 * Lakshmanas Sons were Angada & Chanderkedu
		 * 
		 * Barathas Sons were Daksha & Pushkala
		 * 
		 * Shatrugnas Sons were Shatrugadi & Subahu.
		 */

		//
//		graph.makeLabel("son of").make();
		Vertex das = add("fname", "dasratha", graph);

		// add dasratha's son.
		Vertex ram = addSon("fname", "ram", graph, das);
		Vertex laxman = addSon("fname", "laxman", graph, das);
		Vertex bharat = addSon("fname", "bharat", graph, das);
		Vertex shatrugna = addSon("fname", "shatrugna", graph, das);

		// ram's son
		addSon("fname", "luv", graph, ram);
		addSon("fname", "kush", graph, ram);

		// bharat's son
		addSon("fname", "Daksha", graph, bharat);
		addSon("fname", "Pushkala", graph, bharat);

		// laxman's son
		addSon("fname", "Angada", graph, laxman);
		addSon("fname", "Chanderkedu", graph, laxman);

		// Shatrugna
		addSon("fname", "Shatrugadi", graph, shatrugna);
		addSon("fname", "Subahu", graph, shatrugna);

		graph.commit();

		// iterate
		iterateToLeaf(das);

		TitanMultiVertexQuery mq = graph.multiQuery();
		mq.direction(Direction.IN).labels("son of");

		mq.addVertex((TitanVertex) das);// add root
		mq.addVertex((TitanVertex)ram);
		mq.addVertex((TitanVertex)bharat);
		mq.addVertex((TitanVertex)laxman);
		mq.addVertex((TitanVertex)shatrugna);

		Map<TitanVertex, Iterable<TitanVertex>> dfsResult = mq.vertices();

		System.out.println(dfsResult.size());

		for (TitanVertex key : dfsResult.keySet()) {
			System.out.println("Finding son of" + key.getProperty("fname"));
			Iterable<TitanVertex> sons = dfsResult.get(key);
			Iterator<TitanVertex> sonIter = sons.iterator();
			while (sonIter.hasNext()) {
				System.out.println(sonIter.next().getProperty("fname"));
			}
		}

		// retrieve by multi vertex query

	}

	private static void iterateToLeaf(Vertex das) {

		System.out.println("Finding sons for::" + das.getProperty("fname"));
		Iterable<Vertex> immediateSons = das.getVertices(Direction.IN,
				"son of");
		Iterator<Vertex> iter = immediateSons.iterator();
		// one way is
		while (iter.hasNext()) {
			Vertex v = iter.next();
			// recursive call
			iterateToLeaf(v);

		}
	}

	private static Vertex addSon(String propertyName, String value,
			TitanGraph graph, Vertex father) {
		Vertex son = add(propertyName, value, graph);

		graph.addEdge(null, son, father, "son of");
		return son;
	}

	private static Vertex add(final String propertyName, final String value,
			TitanGraph graph) {
		Vertex vertex = graph.addVertex(null);
		vertex.setProperty(propertyName, value);

		return vertex;
	}
}
