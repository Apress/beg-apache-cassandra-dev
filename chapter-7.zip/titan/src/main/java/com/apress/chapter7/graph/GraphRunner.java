/**
 *  Sample application to store
 *  add twitter_tags as vertices, relations as edges using Titan graph DB and persists graph in Cassandra.
 *  
 */
package com.apress.chapter7.graph;


import java.util.Iterator;

import org.apache.commons.configuration.BaseConfiguration;
import org.apache.commons.configuration.Configuration;

import com.thinkaurelius.titan.core.TitanFactory;
import com.thinkaurelius.titan.core.TitanGraph;
import com.tinkerpop.blueprints.Direction;
import com.tinkerpop.blueprints.Edge;
import com.tinkerpop.blueprints.Vertex;

/**
 * @author vivek.mishra
 * Sample program to use Cassandra as storage backend for graph storage and retrieval.
 * Complete source for Chapter 7 "Reading from Graph" and "Writing to the graph" sections.
 */
public class GraphRunner {

	public static void main(String[] args) 
	{
		Configuration conf = new BaseConfiguration();
		conf.setProperty("storage.backend", "cassandrathrift");
		conf.setProperty("storage.hostname", "localhost");
		conf.setProperty("storage.port", "9160");
		conf.setProperty("storage.keyspace", "twitter");

		TitanGraph graph = TitanFactory.open(conf);
		
		// user
		// add follower
		// has tweets
		// is following
		
		Vertex vivs = graph.addVertex(null);
		vivs.setProperty("fname", "vivek");
		vivs.setProperty("lname", "mishra");
		vivs.setProperty("twitter_tag", "mevivs");
		
		Vertex tweet = graph.addVertex(null);
		tweet.setProperty("body", "Working on Cassandra book for apress");
		tweet.setProperty("tweeted_at", "ss");
		
		graph.addEdge(null, vivs, tweet, "has");

		Vertex apress = graph.addVertex(null);
		apress.setProperty("fname", "apress");
		apress.setProperty("twitter_tag", "apress_team");
		
		graph.addEdge(null, vivs, apress, "following");
		
		graph.commit();
		
//		graph.getv

		Iterable<Vertex> vertices = graph.getVertices();
		Iterator<Vertex> iter = vertices.iterator();

		
		while(iter.hasNext())
		{
			Vertex v = iter.next();
					
			Iterable<Edge> keys = v.getEdges(Direction.BOTH);

			for(Edge key : keys)
			{
				System.out.print(key.getVertex(Direction.IN).toString());
				System.out.print("=>");
				System.out.print(key.getLabel());
				System.out.print("=>");
				System.out.println(key.getVertex(Direction.OUT).toString());

				
			}
		}
    }

}
	