/**
 * © copyright Apress publications.
 */
package com.apress.chapter7.graph;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.commons.configuration.BaseConfiguration;
import org.apache.commons.configuration.Configuration;

import com.thinkaurelius.titan.core.KeyMaker;
import com.thinkaurelius.titan.core.LabelMaker;
import com.thinkaurelius.titan.core.TitanFactory;
import com.thinkaurelius.titan.core.TitanGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.util.wrappers.batch.BatchGraph;
import com.tinkerpop.blueprints.util.wrappers.batch.VertexIDType;

/**
 * @author vivek.mishra
 * 
 *         Program will read data from csv files which is in given below format:
 *         twitter_tag,fname,lname,twitter_tag,fname,lname,edgeName,edgeProperty
 *         
 *         Complete source code for chapter 7 "Bulk loading" section. 
 * 
 */
public class BatchRunner {

	public static void main(String[] args) throws IOException {
		Configuration conf = new BaseConfiguration();
		conf.setProperty("storage.backend", "cassandrathrift");
		conf.setProperty("storage.hostname", "localhost");
		conf.setProperty("storage.port", "9160");
		conf.setProperty("storage.keyspace", "batchprocess");
		conf.setProperty("storage.batch-loading", "true");

		File file = new File("src/main/resources/bulk_load.csv");

		BufferedReader reader = new BufferedReader(new FileReader(file));

		TitanGraph graph = TitanFactory.open(conf);

		KeyMaker maker = graph.makeKey("twitter_tag");
		maker.dataType(String.class);
		maker.make();
		
		graph.makeKey("fname").dataType(String.class).make();

		graph.makeKey("lname").dataType(String.class).make();
		
//		graph.makeKey("contentType").dataType(String.class).make();
		
		LabelMaker labelMaker = graph.makeLabel("contentType");
		labelMaker.make();
		
		graph.makeLabel("following").make();
		
/*		TitanType type = graph.getType("twitter_user");
		
		System.out.println(type.isEdgeLabel());
		System.out.println(type.isPropertyKey());
		System.out.println(graph.getTypes(TitanLabel.class).iterator().hasNext());
//		System.out.println(graph.getTypes(TitanKey.class).iterator().hasNext());
*/		
		BatchGraph bgraph = new BatchGraph(graph, VertexIDType.STRING, 1000);
		while (reader.ready()) {
			String line = reader.readLine();
			StringTokenizer tokenizer = new StringTokenizer(line, ",");
			while (tokenizer.hasMoreTokens()) {
				// System.out.println(tokenizer.nextToken());
				// twitter_tag,fname,lname,twitter_tag,fname,lname,edgeName,edgeProperty
				final String in_twitter_tag = tokenizer.nextToken();
				final String in_fname = tokenizer.nextToken();
				final String in_lname = tokenizer.nextToken();
				final String out_twitter_tag = tokenizer.nextToken();
				final String out_fname = tokenizer.nextToken();
				final String out_lname = tokenizer.nextToken();
				final String edgeName = tokenizer.nextToken();
				final String edgeProperty = tokenizer.nextToken();

				Vertex in = bgraph.addVertex(Math.random() + "");
				in.setProperty("twitter_tag", in_twitter_tag);
				in.setProperty("fname", in_fname);
				in.setProperty("lname", in_lname);

				// bgraph.add
				// out vertex
				Vertex out = bgraph.addVertex(Math.random() + "");
				out.setProperty("twitter_tag", out_twitter_tag);
				out.setProperty("fname", out_fname);
				out.setProperty("lname", out_lname);
				bgraph.addEdge(null, in, out, edgeName);
			}
		}

		bgraph.commit();
	}
	
	//add a logic for retrieval

}
