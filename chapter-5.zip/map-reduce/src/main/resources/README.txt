Prerequisites:
--------------
=> This project is maven 2.x based, Please refer [http://maven.apache.org/guides/getting-started/index.html] for maven setup/installation.
=> Java( jdk version >= 1.7)  must be installed(Sun java preferred) 

How to build:
-------------
=> execute mvn clean install from root folder
=> to generate eclipse project, we need to execute mvn eclipse:clean eclipse:eclipse
=> import as a project in eclipse IDE.

Package structure and files:
----------------------------
=> All source code files are listed in source/map-reduce/src/main/java folder under "com.apress.chapter5.mapreduce.twittercount" package.

Install and run Cassandra server:
---------------------------------
=> Please refer chapter One "Cassandra Basics" for how to install and start Cassandra server.

Database scripts:
----------------
=> Database scripts file is available at src/main/resources/db.txt

How to run:
-----------

1) To run com.apress.chapter5.mapreduce.twittercount.cassandra.TwitterCassandraJob [Recipe 3]
	a) First, we need to run db script after connecting to cassandra-cli or cqlsh(as mentioned in db.script).
	b) Now to run this program, please open TwitterCassandraJob and run as "Java Application" in eclipse.
	


2) To run com.apress.chapter5.mapreduce.twittercount.hdfs.TwitterHDFSJob           [Recipe 2]
	a) First, we need to run db script after connecting to cassandra-cli or cqlsh(as mentioned in db.script).
	b) Now to run this program, please open TwitterHDFSJob and run as "Java Application" in eclipse.
	
3) To run com.apress.chapter5.mapreduce.twittercount.hdfs.DefaultTwitterService
	a) Now to run this program, please open DefaultTwitterService and run as "Java Application" in eclipse.

4) To run com.apress.chapter5.mapreduce.twittercount.hdfs.TwitterHDFSCQLJob           [CQL3 way recipe]
	a) First, we need to run db script after connecting to cassandra-cli or cqlsh(as mentioned in db.script).
	b) Now to run this program, please open TwitterHDFSCQLJob and run as "Java Application" in eclipse.
	