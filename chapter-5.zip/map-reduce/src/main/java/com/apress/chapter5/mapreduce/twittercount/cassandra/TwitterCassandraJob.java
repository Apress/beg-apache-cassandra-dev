package com.apress.chapter5.mapreduce.twittercount.cassandra;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import org.apache.cassandra.hadoop.ColumnFamilyInputFormat;
import org.apache.cassandra.hadoop.ColumnFamilyOutputFormat;
import org.apache.cassandra.hadoop.ConfigHelper;
import org.apache.cassandra.thrift.IndexExpression;
import org.apache.cassandra.thrift.IndexOperator;
import org.apache.cassandra.thrift.SlicePredicate;
import org.apache.cassandra.thrift.SliceRange;
import org.apache.cassandra.utils.ByteBufferUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.util.GenericOptionsParser;

import com.apress.chapter5.mapreduce.twittercount.hdfs.TweetReducer.TweetAggregator;

/**
 * @author vivek.mishra
 * 
 * Before running this program please run DBscripts.txt
 *  
 *  Input
 *  =====
 *  Hadoop job configuration. Program reads record from Cassandra column family "tweetstore". It takes: 
 *  1) "user" value as an input argument
 *  2) If not supplied, default is "mevivs".
 *  
 *  Output
 *  ======
 *  Program writes output "tweet count by user" in "tweetcount" column family.
 */
public class TwitterCassandraJob
{

    private static final String KEYSPACE_NAME = "tweet_keyspace";
    private static final String INPUT_COLUMN_FAMILY = "tweetstore";
    private static final String OUTPUT_COLUMN_FAMILY = "tweetcount";
    
    public static final String COLUMN_NAME="user";

    public static void main(String[] args) throws Exception
    {
        
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        Job job = new Job(conf, "tweet count");
        
        job.setJarByClass(TwitterCassandraJob.class);
        
        // mapper configuration.
        job.setMapperClass(TweetMapper.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        job.setInputFormatClass(ColumnFamilyInputFormat.class);
        
        
        // Reducer configuration
        job.setReducerClass(TweetAggregator.class);
        job.setOutputKeyClass(ByteBuffer.class);
        job.setOutputValueClass(List.class);
        job.setOutputFormatClass(ColumnFamilyOutputFormat.class);


        // Cassandra input column family configuration
        ConfigHelper.setInputRpcPort(job.getConfiguration(), "9160");
        ConfigHelper.setInputInitialAddress(job.getConfiguration(), "localhost");
        ConfigHelper.setInputPartitioner(job.getConfiguration(), "Murmur3Partitioner");
        ConfigHelper.setInputColumnFamily(job.getConfiguration(), KEYSPACE_NAME, INPUT_COLUMN_FAMILY);
        
        job.setInputFormatClass(ColumnFamilyInputFormat.class);

        // Create a slice predicate 
        
        SlicePredicate slicePredicate = new SlicePredicate();
        slicePredicate.setSlice_range(new SliceRange(ByteBufferUtil.EMPTY_BYTE_BUFFER, ByteBufferUtil.EMPTY_BYTE_BUFFER, false, Integer.MAX_VALUE));

        // Prepare index expression.
        IndexExpression ixpr = new IndexExpression();
        ixpr.setColumn_name(ByteBufferUtil.bytes(COLUMN_NAME));
        ixpr.setOp(IndexOperator.EQ);
        ixpr.setValue(ByteBufferUtil.bytes(otherArgs.length > 0 && !StringUtils.isBlank(otherArgs[0])? otherArgs[0]: "mevivs"));
        
        List<IndexExpression> ixpressions = new ArrayList<IndexExpression>();
        ixpressions.add(ixpr);
        
        ConfigHelper.setInputRange(job.getConfiguration(), ixpressions);
        ConfigHelper.setInputSlicePredicate(job.getConfiguration(), slicePredicate);
        
        // Cassandra output family configuration.
        ConfigHelper.setOutputRpcPort(job.getConfiguration(), "9160");
        ConfigHelper.setOutputInitialAddress(job.getConfiguration(), "localhost");
        ConfigHelper.setOutputPartitioner(job.getConfiguration(), "Murmur3Partitioner");
        ConfigHelper.setOutputColumnFamily(job.getConfiguration(), KEYSPACE_NAME, OUTPUT_COLUMN_FAMILY);

        job.setOutputFormatClass(ColumnFamilyOutputFormat.class);

        try
        {
            System.exit(job.waitForCompletion(true) ? 0 : 1);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
}
