package com.apress.chapter5.mapreduce.twittercount.hdfs;

import twitter4j.Twitter;
import twitter4j.TwitterFactory;

/**
 * @author vivek.mishra
 * Twitter connection handler class.
 *
 */
public class ConnectionHandler
{
    private static Twitter twitter = null;

    static
    {
        twitter = new TwitterFactory().getInstance();
    }

    public static Twitter getConnection()
    {
        return twitter;
    }
    
}
