/**
 * 
 */
package com.apress.chapter5.mapreduce.twittercount.hdfs;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cassandra.db.marshal.Int32Type;
import org.apache.cassandra.thrift.Column;
import org.apache.cassandra.thrift.ColumnOrSuperColumn;
import org.apache.cassandra.thrift.Mutation;
import org.apache.cassandra.utils.ByteBufferUtil;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;

/**
 * @author vivek.mishra
 * 
 * Twiiter reducer implementation. Reducer implementation.
 * 
 */

public class TweetReducer
{

    public static class TweetAggregator extends  org.apache.hadoop.mapreduce.Reducer<Text, IntWritable, ByteBuffer, List<Mutation>>
    {

        /* (non-Javadoc)
         * @see org.apache.hadoop.mapreduce.Reducer#reduce(KEYIN, java.lang.Iterable, org.apache.hadoop.mapreduce.Reducer.Context)
         */
        public void reduce(Text word, Iterable<IntWritable> values, Context context) throws IOException,
                InterruptedException
        {
            int sum = 0;
            for (IntWritable val : values)
                sum += val.get();
            
            context.write(ByteBufferUtil.bytes(word.toString()), Collections.singletonList(getMutation(word, sum)));
        }

        /**
         * @param word
         * @param sum
         * @return
         */
        private static Mutation getMutation(Text word, int sum)
        {
            Column c = new Column();
            c.setName(ByteBufferUtil.bytes("count"));
            c.setValue(ByteBufferUtil.bytes(sum));
            c.setTimestamp(System.currentTimeMillis());

            Mutation m = new Mutation();
            m.setColumn_or_supercolumn(new ColumnOrSuperColumn());
            m.column_or_supercolumn.setColumn(c);
            return m;
        }
    }

    public static class TweetCQLAggregator extends  org.apache.hadoop.mapreduce.Reducer<Text, IntWritable, Map<String,ByteBuffer>, List<ByteBuffer>>
    {

    	private static Map<String,ByteBuffer> keys = new HashMap<>();
    	
        /* (non-Javadoc)
         * @see org.apache.hadoop.mapreduce.Reducer#reduce(KEYIN, java.lang.Iterable, org.apache.hadoop.mapreduce.Reducer.Context)
         */
        public void reduce(Text word, Iterable<IntWritable> values, Context context) throws IOException,
                InterruptedException
        {
            int sum = 0;
            for (IntWritable val : values)
                sum += val.get();
            
            System.out.println("writing");
            keys.put("key", ByteBufferUtil.bytes(word.toString()));
            context.write(keys, getBindVariables(word, sum));
        }

        private List<ByteBuffer> getBindVariables(Text word, int sum)
        {
            List<ByteBuffer> variables = new ArrayList<ByteBuffer>();
            variables.add(Int32Type.instance.decompose(sum));         
            return variables;
        }
      }

}
