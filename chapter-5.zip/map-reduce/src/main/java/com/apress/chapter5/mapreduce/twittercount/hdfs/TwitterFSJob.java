package com.apress.chapter5.mapreduce.twittercount.hdfs;

import java.nio.ByteBuffer;
import java.util.List;

import org.apache.cassandra.hadoop.ColumnFamilyOutputFormat;
import org.apache.cassandra.hadoop.ConfigHelper;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import com.apress.chapter5.mapreduce.twittercount.hdfs.TweetMapper.TweetTokenizer;
import com.apress.chapter5.mapreduce.twittercount.hdfs.TweetReducer.TweetAggregator;

/**
 * @author vivek.mishra
 * 
 * Prerequisites
 * ============
 * i) Please execute db script before running this map-reduce program.
 * 
 *  Inputs
 *  ======
 * 1) Program reads data from local file system  directory "/apress/tweetdata/tweets" {see chapter 5 "Map-reduce with Cassandra" chapter for more details}
 * 2) Count on number of tweets by date and user (see {@link TweetTokenizer}
 * 
 *  Output
 *  ======
 *  Program writes output "tweet count by user" in "tweetcount" column family.

 */

public class TwitterFSJob
{

    private static final String KEYSPACE_NAME = "tweet_keyspace";
    private static final String COLUMN_FAMILY = "tweetcount";
    public static final String CONF_COLUMN_NAME = "columnname";


    public static void main(String[] args) throws Exception
    {
        
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        Job job = new Job(conf, "tweet count");

        
        job.setJarByClass(TwitterFSJob.class);
        
        // mapper configuration.
        job.setMapperClass(TweetTokenizer.class);
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        
        
        // Reducer configuration
        job.setReducerClass(TweetAggregator.class);
        job.setOutputKeyClass(ByteBuffer.class);
        job.setOutputValueClass(List.class);
        job.setOutputFormatClass(ColumnFamilyOutputFormat.class);


        // Cassandra configuration.
        ConfigHelper.setOutputRpcPort(job.getConfiguration(), "9160");
        ConfigHelper.setOutputInitialAddress(job.getConfiguration(), "localhost");
        ConfigHelper.setOutputPartitioner(job.getConfiguration(), "Murmur3Partitioner");
        ConfigHelper.setOutputColumnFamily(job.getConfiguration(), KEYSPACE_NAME, COLUMN_FAMILY);

//        job.getConfiguration().set(CONF_COLUMN_NAME, "count");
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        job.setOutputFormatClass(ColumnFamilyOutputFormat.class);

        try
        {
            System.exit(job.waitForCompletion(true) ? 0 : 1);
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
}
