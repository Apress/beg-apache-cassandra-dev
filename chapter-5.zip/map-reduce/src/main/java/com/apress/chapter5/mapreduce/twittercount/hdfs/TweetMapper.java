/**
 * 
 */
package com.apress.chapter5.mapreduce.twittercount.hdfs;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * @author vivek.mishra
 * 
 * Tweet tokenizer to tokenize using '\001' as a delimeter.
 * {@link Mapper} implementation. 
 */


public class TweetMapper
{

public static class TweetTokenizer extends Mapper<LongWritable, Text, Text, IntWritable>
{
    private final static IntWritable one = new IntWritable(1);
    
    
    /* (non-Javadoc)
     * @see org.apache.hadoop.mapreduce.Mapper#map(KEYIN, VALUEIN, org.apache.hadoop.mapreduce.Mapper.Context)
     */
    public void map(LongWritable key, Text value, Context context) 
    throws IOException, InterruptedException
    {
        // split into tokens and pass  date and count as key.
        String[] values = StringUtils.split(value.toString(), "\001");
        
        if(values.length >=2 && values.length <=3)
        {
            context.write(new Text(values[0]), one);  // count on by date.
            context.write(new Text(values[1]), one); // count on users.
        }

    }
}
}
