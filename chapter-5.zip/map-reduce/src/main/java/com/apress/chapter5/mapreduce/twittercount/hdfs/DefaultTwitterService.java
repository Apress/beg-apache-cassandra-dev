package com.apress.chapter5.mapreduce.twittercount.hdfs;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;

/**
 * @author vivek.mishra
 *
 * Twitter service to connect with twitter account and retrieving tweets related to "apress".
 */
public class DefaultTwitterService
{

    public static void main(String[] args) throws TwitterException
    {
        DefaultTwitterService service = new DefaultTwitterService();
        service.searchTweets("apress");
    }

    public void searchTweets(String searchKeyword) throws TwitterException
    {
        Twitter connection = ConnectionHandler.getConnection();
        
        Query query = new Query("apress");

        QueryResult result = connection.search(query);

        
        int count = 0;

        final String filePath = "/home/vivek/Desktop/tweets"; // you may change it as per your configuration 
        File file = new File(filePath);
        FileOutputStream fos = null;
        try
        {
            fos = new FileOutputStream(file);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        do
        {
            List<Status> statuses = result.getTweets();

            if (count < 100000)
            {
                for (Status status : statuses)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.append(status.getUser().getCreatedAt());
                    sb.append("\001");
                    if (status.getUser() != null)
                    {
                        sb.append(status.getUser().getName());
                        sb.append("\001");
                    }
                    sb.append(status.getText());
                    sb.append("\n");
                    try
                    {
                        fos.write(sb.toString().getBytes());
                    }
                    catch (IOException e)
                    {
                        e.printStackTrace();
                    }
                    count++;

                }
            } else
            {
                break;
            }
        }
        while ((query = result.nextQuery()) != null);

        try
        {
            fos.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

    }
}
