package com.impetus.cql3bulkloader.thrift;

import static org.apache.cassandra.utils.ByteBufferUtil.bytes;
import static org.apache.cassandra.utils.UUIDGen.decompose;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.UUID;

import org.apache.cassandra.db.marshal.AsciiType;
import org.apache.cassandra.dht.Murmur3Partitioner;
import org.apache.cassandra.io.sstable.SSTableSimpleUnsortedWriter;

/**
 * @author vivek.mishra
 * 
 * This program's sole purpose is to demonstrate how to marshal and persist data on local file system in CQL3 format.
 * 
 *  
 * How to run:
 * ===========
 *
 *  1) connect to cassandra-cli and create keyspace 
 *     create keyspace ThriftDemo;
 *  
 *  2) Create column family Users as:
 *  
 *  use ThriftDemo;

 *  create column family Users;
 *
 *  3) CSVInput.csv(under src/main/resources) file contains:
 *      user_id,firstname,lastname,password,age,email with "," as delimeter.
 *  
 *  4) Provide path as input argument(default path is src/main/resources/CSVInput.csv) and run as java application.
 *  
 *   Output:
 *   ======
 *   It will create a directory structure data/ThriftDemo/Users at root level. Now we are ready to use "sstableloader" to upload these ".db" files in cassandra column family.
 *   We need to create a folder structure similar to cassandra data folder. By default it is data/$KEYSPACE/$COLUMNFamily. 
 *   
 *   
 *   
 *   Running sstableLoader
 *   =================
 *   
 *   $CASSANDRA_HOME/bin/sstableloader -d localhost data/ThriftDemo/Users/
 *   
 *   it will load data into sstables.
 *   
 *   Fire list Users and sample output will be like:
 *                     
==============================================================================
[default@ThriftDemo] list Users;
Using default limit of 100
Using default column limit of 100
-------------------
RowKey: 5bd8c586ae4411e097b80026b0ea8cd0
=> (column=616765, value=0000000000000016, timestamp=1380201955251000)
=> (column=656d61696c, value=766976656b2e6d697368726140696d70657475732e636f2e696e, timestamp=1380201955251000)
=> (column=66697273746e616d65, value=766976656b, timestamp=1380201955251000)
=> (column=6c6173746e616d65, value=6d6973687261, timestamp=1380201955251000)
=> (column=70617373776f7264, value=344a633273, timestamp=1380201955251000)
-------------------
RowKey: 4bd8cb58ae4412e0a2b80026b0ed9cd1
=> (column=616765, value=000000000000000c, timestamp=1380201955251000)
=> (column=656d61696c, value=6269676461746140696d70657475732e636f6d, timestamp=1380201955251000)
=> (column=66697273746e616d65, value=696d7065747573, timestamp=1380201955251000)
=> (column=6c6173746e616d65, value=62696764617461, timestamp=1380201955251000)
=> (column=70617373776f7264, value=732161306d6c, timestamp=1380201955251000)
-------------------
RowKey: 1ce7cb58ae4412e0a2b80026b0ad21ab
=> (column=616765, value=000000000000000c, timestamp=1380201955251000)
=> (column=656d61696c, value=73616e6a61792e736861726d6140696d70657475732e636f6d, timestamp=1380201955251000)
=> (column=66697273746e616d65, value=53616e6a6179, timestamp=1380201955251000)
=> (column=6c6173746e616d65, value=536861726d61, timestamp=1380201955251000)
=> (column=70617373776f7264, value=7329334233, timestamp=1380201955251000)

3 Rows Returned.
                                                                 
================================================================================================================
 *   
 */

public class DataImportExample
{
    static String filename;

    public static void main(String[] args) throws IOException
    {
        if (args.length == 0)
        {
            filename = "src/main/resources/CSVInput.csv";
        } else
        {
            filename = args[0];
        }
        BufferedReader reader = new BufferedReader(new FileReader(filename));

        String keyspace = "ThriftDemo";
        
        String columnFamily = "Users";
        
        // create cassandra type structure  default is data/KEYSPACE/users
        
        File directory = new File("data");
        
        if (!directory.exists())
        {
            directory.mkdir();
        }

        directory = new File(directory.getPath()+"/"+keyspace);
        if (!directory.exists())
            directory.mkdir();

        directory = new File(directory.getPath()+"/"+columnFamily);
        if (!directory.exists())
            directory.mkdir();

        SSTableSimpleUnsortedWriter usersWriter = new SSTableSimpleUnsortedWriter(
                directory,
                new Murmur3Partitioner(),
                keyspace,
                "Users",
                AsciiType.instance,
                null,
                64);

        String line;
        int lineNumber = 1;
        CsvEntry entry = new CsvEntry();
        // There is no reason not to use the same timestamp for every column in that example.
        long timestamp = System.currentTimeMillis() * 1000;
        while ((line = reader.readLine()) != null)
        {
            if (entry.parse(line, lineNumber))
            {
                ByteBuffer uuid = ByteBuffer.wrap(decompose(entry.key));
                usersWriter.newRow(uuid);
                usersWriter.addColumn(bytes("firstname"), bytes(entry.firstname), timestamp);
                usersWriter.
                addColumn(bytes("lastname"), bytes(entry.lastname), timestamp);
                usersWriter.addColumn(bytes("password"), bytes(entry.password), timestamp);
                usersWriter.addColumn(bytes("age"), bytes(entry.age), timestamp);
                usersWriter.addColumn(bytes("email"), bytes(entry.email), timestamp);
            }
            lineNumber++;
        }
        // Don't forget to close!
        usersWriter.close();
        System.exit(0);
    }

    static class CsvEntry
    {
        UUID key;
        String firstname;
        String lastname;
        String password;
        long age;
        String email;

        boolean parse(String line, int lineNumber)
        {
            // Ghetto csv parsing
            String[] columns = line.split(",");
            if (columns.length != 6)
            {
                System.out.println(String.format("Invalid input '%s' at line %d of %s", line, lineNumber, filename));
                return false;
            }
            try
            {
                key = UUID.fromString(columns[0].trim());
                firstname = columns[1].trim();
                lastname = columns[2].trim();
                password = columns[3].trim();
                age = Long.parseLong(columns[4].trim());
                email = columns[5].trim();
                return true;
            }
            catch (NumberFormatException e)
            {
                System.out.println(String.format("Invalid number in input '%s' at line %d of %s", line, lineNumber, filename));
                return false;
            }
        }
    }
}