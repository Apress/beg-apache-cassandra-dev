package com.impetus.cql3bulkloader.cql3;

/**
 * Disclaimer:
 * This file is an example on how to use the Cassandra SSTableSimpleUnsortedWriter class to create
 * sstables from a csv input file.
 * While this has been tested to work, this program is provided "as is" with no guarantee. Moreover,
 * it's primary aim is toward simplicity rather than completness. In partical, don't use this as an
 * example to parse csv files at home.
 */
import static org.apache.cassandra.utils.ByteBufferUtil.bytes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

import org.apache.cassandra.db.marshal.AsciiType;
import org.apache.cassandra.db.marshal.CompositeType;
import org.apache.cassandra.db.marshal.IntegerType;
import org.apache.cassandra.db.marshal.SetType;
import org.apache.cassandra.db.marshal.UTF8Type;
import org.apache.cassandra.db.marshal.UUIDType;
import org.apache.cassandra.dht.Murmur3Partitioner;
import org.apache.cassandra.exceptions.InvalidRequestException;
import org.apache.cassandra.io.compress.CompressionParameters;
import org.apache.cassandra.io.sstable.SSTableSimpleUnsortedWriter;

/**
 * @author vivek.mishra
 * 
 *         This program's sole purpose is to demonstrate how to marshal and
 *         persist data on local file system in CQL3 format.
 * 
 *         Problem description: ==================== Since CQL3's inception,
 *         Thrift and CQL3 inter operability is an issue and have been widely
 *         discussed in community. Cassandra recommends to create CQL3
 *         table(column family) with "WITH COMPACT STORAGE" option for backward
 *         compatibility. However "collection" data types are not supported with
 *         "WITH COMPACT STORAGE".
 * 
 *         How to load data using bulkloader in a CQL3 format column family
 *         (WITHOUT COMPACT STORAGE) containg collection and non collection
 *         columns?
 * 
 *         Solution: ========= CQL3 column data type is of {@link CompositeType}
 *         by default. Hence solution is, we need to marshal(e.g. decompose) our
 *         data set in same way. Additionally i preferred using SnappyCompressor
 *         over LZ4Compressor.
 * 
 *         How to run: ===========
 * 
 *         1) connect to cqlsh and create keyspace 
 *         create keyspace "Cql3Demo"
 *         with replication = { 'class' : 'SimpleStrategy' ,
 *         'replication_factor':3};
 * 
 *         2) Create column family Users(containing collection and non
 *         collection columns) as:
 * 
 *         use "Cql3Demo"; create table "Users"(user_id uuid PRIMARY
 *         KEY,firstname text,lastname text, password text,email text, age int,
 *         addresses set<text>);
 * 
 *         3) CSVInput.csv(under src/main/resources) file contains:
 *         user_id,firstname,lastname,password,age,email with "," as delimeter.
 * 
 *         4) Provide path as input argument and run as java application.
 * 
 *         Output: ====== It will create a directory data/Cql3Demo at root
 *         level. Now we are ready to use "sstableloader" to upload these ".db"
 *         files in cassandra column family. We need to create a folder
 *         structure similar to cassandra data folder. By default it is
 *         data/$KEYSPACE/$COLUMNFamily.
 * 
 * 
 * 
 *         Running sstableLoader =================
 * 
 *         $CASSANDRA_HOME/bin/sstableloader -d localhost data/Cql3Demo/Users/
 * 
 *         it will load data into sstables.
 * 
 *         Fire select * from "Users" and sample output will be like:
 * 
 *         user_id | addresses | age | email | firstname | lastname | password
 *         --------------------------------------+-----------+-----+------------
 *         ----------------+-----------+----------+----------
 *         5bd8c586-ae44-11e0-97b8-0026b0ea8cd0 | null | 22 |
 *         vivek.mishra@impetus.co.in | vivek | mishra | 4Jc2s
 *         4bd8cb58-ae44-12e0-a2b8-0026b0ed9cd1 | null | 12 |
 *         bigdata@impetus.com | impetus | bigdata | s!a0ml
 *         1ce7cb58-ae44-12e0-a2b8-0026b0ad21ab | null | 12 |
 *         sanjay.sharma@impetus.com | Sanjay | Sharma | s)3B3
 * 
 * 
 *         In case required to load collection type values, we can simply
 *         decompose them as: MapType.getInstance(UTF8Type.instance,
 *         UTF8Type.instance).decompose(new HashMap<String, String>);
 * 
 */

public class DataImportExample
{
    static String filename;

    public static void main(String[] args) throws IOException, InvalidRequestException
    {
        if (args.length == 0)
        {
            filename = "src/main/resources/CSVInput.csv";
        }
        else
        {
            filename = args[0];
        }
        BufferedReader reader = new BufferedReader(new FileReader(filename));

        String keyspace = "Cql3Demo";

        String columnFamily = "Users";

        // create cassandra type structure default is data/KEYSPACE/users

        File directory = new File("data");

        if (!directory.exists())
        {
            directory.mkdir();
        }

        directory = new File(directory.getPath() + "/" + keyspace);
        if (!directory.exists())
            directory.mkdir();

        directory = new File(directory.getPath() + "/" + columnFamily);
        if (!directory.exists())
            directory.mkdir();

        SSTableSimpleUnsortedWriter usersWriter = new SSTableSimpleUnsortedWriter(directory, new Murmur3Partitioner(),
                keyspace, "Users", AsciiType.instance, null, 64, new CompressionParameters(
                        org.apache.cassandra.io.compress.SnappyCompressor.create(Collections
                                .<String, String> emptyMap())));

        String line;
        int lineNumber = 1;
        CsvEntry entry = new CsvEntry();
        // There is no reason not to use the same timestamp for every column in
        // that example.
        long timestamp = System.currentTimeMillis() * 1000;

//        Set<String> addresses = new HashSet<String>();
//        addresses.add("{Noida");
//        addresses.add("'NSEZ'");
        while ((line = reader.readLine()) != null)
        {
            if (entry.parse(line, lineNumber))
            {
                ByteBuffer uuid = UUIDType.instance.decompose(entry.key);

                usersWriter.newRow(uuid);

                List types = new ArrayList();
                types.add(UTF8Type.instance);

                CompositeType compositeType = CompositeType.getInstance(types);

                List numericTypes = new ArrayList();
                numericTypes.add(IntegerType.instance);

                CompositeType numericType = CompositeType.getInstance(numericTypes);

                // marshall values as compositeType validator.

//                collectionColumn(keyspace, columnFamily, usersWriter, timestamp, types);

                usersWriter.addColumn(compositeType.decompose("firstname"),
                        compositeType.decompose(bytes(entry.firstname)), timestamp); // marshall
                                                                                     // values
                                                                                     // as
                                                                                     // compositeType
                                                                                     // validator.
                usersWriter.addColumn(compositeType.decompose("lastname"),
                        compositeType.decompose(bytes(entry.lastname)), timestamp);
                usersWriter.addColumn(compositeType.decompose("password"),
                        compositeType.decompose(bytes(entry.password)), timestamp);

                usersWriter.addColumn(compositeType.decompose("age"), numericType.decompose(bytes(entry.age)),
                        timestamp);

                usersWriter.addColumn(compositeType.decompose("email"), compositeType.decompose(bytes(entry.email)),
                        timestamp);

              SetType<String> addressType = new SetType<String>(UTF8Type.instance);

              ByteBuffer byteBuffer1 = compositeType.decompose("addresses");  // column name
              ByteBuffer byteBuffer2 = compositeType.decompose("noida");   // set value
//              ByteBuffer byteBuffer3 = compositeType.decompose("noida1"); 
              
              ByteBuffer bb = ByteBuffer.allocate(byteBuffer2.capacity()+byteBuffer1.capacity());
              bb.put(byteBuffer1);
              bb.put(byteBuffer2);
              bb.flip();
              

              
              /**
               *   Out put will be 
               *    user_id                              | addresses | age | email                      | firstname | lastname | password
--------------------------------------+-----------+-----+----------------------------+-----------+----------+----------
 5bd8c586-ae44-11e0-97b8-0026b0ea8cd0 |   {noida} |  22 | vivek.mishra@impetus.co.in |     vivek |   mishra |    4Jc2s
 4bd8cb58-ae44-12e0-a2b8-0026b0ed9cd1 |   {noida} |  12 |        bigdata@impetus.com |   impetus |  bigdata |   s!a0ml
 1ce7cb58-ae44-12e0-a2b8-0026b0ad21ab |   {noida} |  12 |  sanjay.sharma@impetus.com |    Sanjay |   Sharma |    s)3B3


               */

              usersWriter.addColumn(bb,addressType.decompose(new HashSet<String>()),timestamp);

              
              
              
              // For Map support
              // alter table "Users" add mapCol  map<text,text>;

              byteBuffer1 = compositeType.decompose("mapcol");  // map column name
              byteBuffer2 = compositeType.decompose("noida");   // map column key
              
              bb = ByteBuffer.allocate(byteBuffer2.capacity()+byteBuffer1.capacity());
              bb.put(byteBuffer1);
              bb.put(byteBuffer2);
              bb.flip();

              usersWriter.addColumn(bb,compositeType.decompose(bytes("vivek")),timestamp);  // map value
              
              
                  // OUTPUT with MAP
/**
               
              user_id                              | addresses | age | email                      | firstname | lastname | mapcol         | password
              --------------------------------------+-----------+-----+----------------------------+-----------+----------+----------------+----------
               5bd8c586-ae44-11e0-97b8-0026b0ea8cd0 |   {noida} |  22 | vivek.mishra@impetus.co.in |     vivek |   mishra | {noida: vivek} |    4Jc2s
               4bd8cb58-ae44-12e0-a2b8-0026b0ed9cd1 |   {noida} |  12 |        bigdata@impetus.com |   impetus |  bigdata | {noida: vivek} |   s!a0ml
               1ce7cb58-ae44-12e0-a2b8-0026b0ad21ab |   {noida} |  12 |  sanjay.sharma@impetus.com |    Sanjay |   Sharma | {noida: vivek} |    s)3B3
*/
              
              // DO NOT DELETE IT!
//              int i =  setCompositeType.split(bb).length;
//             System.out.println(i);
             

            }
            lineNumber++;
        }
        // Don't forget to close!
        usersWriter.close();
        System.exit(0);
    }
    


    static class CsvEntry
    {
        UUID key;

        String firstname;

        String lastname;

        String password;

        int age;

        String email;

        boolean parse(String line, int lineNumber)
        {
            // Ghetto csv parsing
            String[] columns = line.split(",");
            if (columns.length != 6)
            {
                System.out.println(String.format("Invalid input '%s' at line %d of %s", line, lineNumber, filename));
                return false;
            }
            try
            {
                key = UUID.fromString(columns[0].trim());
                firstname = columns[1].trim();
                lastname = columns[2].trim();
                password = columns[3].trim();
                age = Integer.parseInt(columns[4].trim());
                email = columns[5].trim();
                return true;
            }
            catch (NumberFormatException e)
            {
                System.out.println(String.format("Invalid number in input '%s' at line %d of %s", line, lineNumber,
                        filename));
                return false;
            }
        }
    }
}